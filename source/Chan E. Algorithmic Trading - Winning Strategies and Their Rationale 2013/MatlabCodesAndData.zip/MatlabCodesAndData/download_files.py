import os
import requests
import json
from concurrent.futures import ThreadPoolExecutor

BASE_URL = "https://epchan.com/img/book2/"
FILES_JSON_URL = "https://epchan.com/img/book2/files.json"

def download_file(filename):
    url = f"{BASE_URL}{filename}"
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        with open(filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"Downloaded: {filename}")
    except Exception as e:
        print(f"Failed to download {filename}: {e}")

def main():
    print("Fetching file list...")
    try:
        r = requests.get(FILES_JSON_URL)
        r.raise_for_status()
        files = r.json()
    except Exception as e:
        print(f"Error fetching file list: {e}")
        return

    print(f"Found {len(files)} files. Starting download...")

    with ThreadPoolExecutor(max_workers=5) as executor:
        executor.map(download_file, files)

    print("Download complete.")

if __name__ == "__main__":
    main()
